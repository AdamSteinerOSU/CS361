from flask import Flask, render_template, url_for, request, redirect, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
from sqlalchemy import text



app = Flask(__name__)
# old
# app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///test.db'
# SQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Adamrocks123!@localhost/cs361'
db = SQLAlchemy(app)

# games table from database
class games(db.Model):
    gameID = db.Column(db.Integer, primary_key=True)
    game_name = db.Column(db.String(200), nullable=False)
    publisher = db.Column(db.String(200))
    date_published = db.Column(db.String(200), default=0)
    rating = db.Column(db.Integer, default=0)
    genres = db.relationship('genres', secondary='game_genres', backref=db.backref('games', lazy='dynamic'))
    platforms = db.relationship('platforms', secondary='game_platforms', backref=db.backref('games', lazy='dynamic'))
    game_description  = db.Column(db.String(500), nullable=False)
    images = db.Column(db.String(245), nullable=False)

    def __repr__(self):
        return '<Game %r>' % self.gameID

# genres table from database
class genres(db.Model):
    genreID = db.Column(db.Integer, primary_key=True)
    genre_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<genre %r>' % self.genreID

# game_genres table from database
class game_genres(db.Model):
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)
    genreID = db.Column(db.Integer, db.ForeignKey('genres.genreID'), primary_key=True)

    def __repr__(self):
        return '<genres %r>' %self.gameID

# platforms table from database
class platforms(db.Model):
    platformID = db.Column(db.Integer, primary_key=True)
    platform_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<platform %r>' % self.platformID

# game_platforms table from database   
class game_platforms(db.Model):
    platformID = db.Column(db.Integer, db.ForeignKey('platforms.platformID'), primary_key=True)
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)

    def __repr__(self):
        return '<game_platforms %r>' %self.gameID

# favorites table from database
class favorites(db.Model):
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)

    def __repr__(self):
        return '<favorites %r>' %self.gameID

# index page
@app.route('/', methods=['GET'])
def index():
    valid_games = games.query.order_by(games.gameID).all()
    favorite_games = {fav.gameID for fav in favorites.query.all()}
    if request.method == 'GET':
        return render_template('index.html', videogames=valid_games, favorite_games=favorite_games)

# POST route for favorite/unfavorite a game
@app.route('/favorite_game', methods=['POST'])
def add_favorite():
    game_id = request.form.get('gameID')
    if game_id:
        game_id = int(game_id)
        existing_favorite = favorites.query.filter_by(gameID=game_id).first()
        if not existing_favorite:
            new_favorite = favorites(gameID=game_id)
            db.session.add(new_favorite)
            db.session.commit()
            return jsonify({'status': 'added'})
        else:
            db.session.delete(existing_favorite)
            db.session.commit()
            return jsonify({'status': 'removed'})
    return jsonify({'status': 'error', 'message': 'Invalid gameID'})

# favorite page
@app.route('/favorites', methods=['GET'])
def favorite():
    favorite_games = db.session.query(games).join(favorites, games.gameID == favorites.gameID).all()
    favorite_games_list = {fav.gameID for fav in favorites.query.all()}
    return render_template('favorites.html', favorite_games=favorite_games, favorite_games_list=favorite_games_list) 

# recommended page
@app.route('/recommended', methods=['GET'])
def recommended():
    valid_games = games.query.order_by(games.gameID).all()
    favorite_games = {fav.gameID for fav in favorites.query.all()}
    if request.method == 'GET':
        return render_template('recommended.html', games=valid_games, favorite_games=favorite_games) 

# search page
@app.route('/search', methods=['GET'])
def search():
    search_name = request.args.get('search-name', '')
    search_genre = request.args.get('search-genre', '')
    search_platform = request.args.get('search-platform', '')
    search_year = request.args.get('search-year', '')
    search_publisher = request.args.get('search-publisher', '')
    search_rating = request.args.get('search-rating', '')


    genres_list = genres.query.all()
    platform_list = platforms.query.all()
    publishers = db.session.query (games.publisher).distinct().all()
    unique_publishers = [publisher[0] for publisher in publishers]
    favorite_games = {fav.gameID for fav in favorites.query.all()}

    filtered_games = games.query

    if search_name:
        filtered_games = filtered_games.filter(games.game_name.ilike(f'%{search_name}%'))

    if search_genre:
        filtered_games = filtered_games.join(game_genres).join(genres).filter(genres.genre_name == search_genre)

    if search_platform:
        filtered_games = filtered_games.join(game_platforms).join(platforms).filter(platforms.platform_name == search_platform)

    if search_year:
        start_year, end_year = map(int, search_year.split('-'))
        filtered_games = filtered_games.filter(games.date_published.between(start_year, end_year))

    if search_publisher:
        filtered_games = filtered_games.filter(games.publisher == search_publisher)

    if search_rating:
        start_rating, end_rating = map(float, search_rating.split('-'))
        filtered_games = filtered_games.filter(games.rating.between(start_rating, end_rating))

    filtered_games = filtered_games.order_by(games.gameID).all()

    return render_template('search.html', games=filtered_games, genres = genres_list, platforms = platform_list, publishers = unique_publishers, favorite_games=favorite_games)

# individual game pages, based on gameID passed
@app.route('/game/<int:gameID>', methods=['GET'])
def game_detail(gameID):
    game = games.query.get_or_404(gameID)
    favorite_games = {fav.gameID for fav in favorites.query.all()}
    return render_template('game_detail.html', game=game, favorite_games=favorite_games)


# with app.app_context():
#     result = db.session.execute(text('SELECT * FROM game_platforms')).fetchall()
#     print(result)

if __name__ == "__main__":
    app.run(debug=True)
