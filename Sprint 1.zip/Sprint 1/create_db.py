import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="Adamrocks123!",
)

my_cursor = mydb.cursor()

my_cursor.execute("CREATE DATABASE IF NOT EXISTS CS361")

my_cursor.execute("SHOW DATABASES")
for db in my_cursor:
    print(db)

