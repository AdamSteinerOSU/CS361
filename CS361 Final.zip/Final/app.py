from flask import Flask, render_template, url_for, request, redirect, jsonify, session
from flask_sqlalchemy import SQLAlchemy
import requests
from flask_cors import CORS
from functools import wraps
from flask_caching import Cache

import time

app = Flask(__name__)
CORS(app)

# SQL configuration
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Adamrocks123!@localhost/cs361'
app.secret_key = 'secretKey'
db = SQLAlchemy(app)

# Cache for recommended games
app.config['CACHE_TYPE'] = 'simple'  # Use simple cache for in-memory caching
app.config['CACHE_DEFAULT_TIMEOUT'] = 5  # Cache timeout in seconds (5 seconds)
cache = Cache(app)


# Helper function to require login
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


class users(db.Model):
    userID = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(200), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username


# Define models
class games(db.Model):
    gameID = db.Column(db.Integer, primary_key=True)
    game_name = db.Column(db.String(200), nullable=False)
    publisher = db.Column(db.String(200))
    date_published = db.Column(db.String(200), default=0)
    rating = db.Column(db.Integer, default=0)
    genres = db.relationship('genres', secondary='game_genres', backref=db.backref('games', lazy='dynamic'))
    platforms = db.relationship('platforms', secondary='game_platforms', backref=db.backref('games', lazy='dynamic'))
    game_description  = db.Column(db.String(500), nullable=False)
    images = db.Column(db.String(245), nullable=False)

    def __repr__(self):
        return '<Game %r>' % self.gameID


class genres(db.Model):
    genreID = db.Column(db.Integer, primary_key=True)
    genre_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<genre %r>' % self.genreID


class game_genres(db.Model):
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)
    genreID = db.Column(db.Integer, db.ForeignKey('genres.genreID'), primary_key=True)

    def __repr__(self):
        return '<genres %r>' %self.gameID


class platforms(db.Model):
    platformID = db.Column(db.Integer, primary_key=True)
    platform_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<platform %r>' % self.platformID


class game_platforms(db.Model):
    platformID = db.Column(db.Integer, db.ForeignKey('platforms.platformID'), primary_key=True)
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)

    def __repr__(self):
        return '<game_platforms %r>' %self.gameID


class favorites(db.Model):
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)
    userID = db.Column(db.String(200), db.ForeignKey('users.userID'), primary_key=True)

    def __repr__(self):
        return '<favorites %r>' %self.gameID


# Routes
@app.route('/', methods=['GET'])
@login_required
def index():
    user_id = session['user_id']
    user = users.query.filter_by(userID=user_id).first()
    username = user.username if user else None
    valid_games = games.query.order_by(games.gameID).all()
    favorite_games = {fav.gameID for fav in favorites.query.filter_by(userID=user_id).all()}
    return render_template('index.html', videogames=valid_games, favorite_games=favorite_games, username=username)


@app.route('/favorite_game', methods=['POST'])
def add_favorite():
    if 'user_id' not in session:
        return jsonify({'status': 'error', 'message': 'User not logged in'}), 401

    game_id = request.form.get('gameID')
    user_id = session['user_id']

    if game_id:
        game_id = int(game_id)
        existing_favorite = favorites.query.filter_by(gameID=game_id).first()
        if not existing_favorite:
            new_favorite = favorites(gameID=game_id, userID=user_id)
            db.session.add(new_favorite)
            db.session.commit()
            return jsonify({'status': 'added'})
        else:
            db.session.delete(existing_favorite)
            db.session.commit()
            return jsonify({'status': 'removed'})
    return jsonify({'status': 'error', 'message': 'Invalid gameID'})


@app.route('/favorites', methods=['GET'])
@login_required
def favorite():
    user_id = session['user_id']
    favorite_games = games.query.join(favorites).filter(favorites.userID == user_id).all()
    favorite_games_list = [game.gameID for game in favorite_games]
    return render_template('favorites.html', favorite_games=favorite_games, favorite_games_list=favorite_games_list)


@app.route('/search', methods=['GET'])
@login_required
def search():
    user_id = session['user_id']
    search_name = request.args.get('search-name', '')
    search_genre = request.args.get('search-genre', '')
    search_platform = request.args.get('search-platform', '')
    search_year = request.args.get('search-year', '')
    search_publisher = request.args.get('search-publisher', '')
    search_rating = request.args.get('search-rating', '')

    genres_list = genres.query.all()
    platform_list = platforms.query.all()
    publishers = db.session.query(games.publisher).distinct().all()
    unique_publishers = [publisher[0] for publisher in publishers]
    favorite_games = {fav.gameID for fav in favorites.query.filter_by(userID=user_id).all()}

    filtered_games = games.query

    if search_name:
        filtered_games = filtered_games.filter(games.game_name.ilike(f'%{search_name}%'))

    if search_genre:
        filtered_games = filtered_games.join(game_genres).join(genres).filter(genres.genre_name == search_genre)

    if search_platform:
        filtered_games = filtered_games.join(game_platforms).join(platforms).filter(platforms.platform_name == search_platform)

    if search_year:
        start_year, end_year = map(int, search_year.split('-'))
        filtered_games = filtered_games.filter(games.date_published.between(start_year, end_year))

    if search_publisher:
        filtered_games = filtered_games.filter(games.publisher == search_publisher)

    if search_rating:
        start_rating, end_rating = map(float, search_rating.split('-'))
        filtered_games = filtered_games.filter(games.rating.between(start_rating, end_rating))

    filtered_games = filtered_games.order_by(games.gameID).all()

    return render_template('search.html', games=filtered_games, genres=genres_list, platforms=platform_list, publishers=unique_publishers, favorite_games=favorite_games)


@app.route('/game/<int:gameID>', methods=['GET'])
def game_detail(gameID):
    game = games.query.get_or_404(gameID)
    favorite_games = {fav.gameID for fav in favorites.query.all()}

    try:
        response = requests.get('http://localhost:5004/api/get_trailer', params={'game_name': game.game_name})
        trailer = response.json()
        if response.status_code == 200:
            trailer_url = trailer.get('url')
            trailer_title = trailer.get('title')
        else:
            trailer_url = None
            trailer_title = None
    except requests.exceptions.RequestException as e:
        print(f"Error fetching trailer: {e}")
        trailer_url = None
        trailer_title = None

    return render_template('game_detail.html', game=game, favorite_games=favorite_games, trailer_url=trailer_url,
                           trailer_title=trailer_title)


@app.route('/random_image', methods=['GET'])
def random_image():
    try:
        # Makes an HTTP GET request to the randomImage microservice
        response = requests.get('http://localhost:5001/api/generate')
        response.raise_for_status()  # Check if the request was successful
        data = response.json()  # Parse the JSON response
        return render_template('random.html', image_path=data['image_path'])
    except requests.exceptions.RequestException as e:
        # Handle any errors that occur during the request
        return jsonify({'error': str(e)}), 500


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')

        if not username:
            return redirect(url_for('login', error="Username is required"))

        try:
            response = requests.post(
                'http://localhost:5002/login',
                json={'username': username}
            )
            response.raise_for_status()

            user = response.json()  # Parse JSON response

            if 'user_id' in user:
                session['user_id'] = user['user_id']
                return redirect(url_for('index'))
            else:
                return redirect(url_for('login', error="Invalid username"))
        except requests.exceptions.HTTPError as err:
            if err.response.status_code == 401:
                return redirect(url_for('login', error="Invalid username"))
            else:
                return redirect(url_for('login', error=f"Request error: {str(err)}"))
        except requests.exceptions.RequestException as e:
            return redirect(url_for('login', error=f"Request error: {str(e)}"))

    return render_template('login.html')


@app.route('/logout', methods=['GET'])
@login_required
def logout():
    # Make a request to the authentication microservice to logout
    requests.post('http://localhost:5002/logout', cookies=dict(session_id=session.get('session_id')))
    session.pop('user_id', None)
    return redirect(url_for('login'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')

        if not username:
            return redirect(url_for('register', error="Username is required"))

        existing_user = users.query.filter_by(username=username).first()
        if existing_user:
            return redirect(url_for('register', error="Username already exists"))

        new_user = users(username=username)
        db.session.add(new_user)
        db.session.commit()

        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/recommended', methods=['GET'])
@login_required
@cache.cached(key_prefix='recommended_games')
def recommended():
    try:
        # Fetch recommended games from the microservice
        response = requests.get(
            'http://localhost:5003/api/recommended')
        response.raise_for_status()
        recommended_games_ids = response.json().get('game_ids', [])

        # Fetch game details from the database
        recommended_games = games.query.filter(games.gameID.in_(recommended_games_ids)).all()
        favorite_games = {fav.gameID for fav in favorites.query.filter_by(userID=session['user_id']).all()}

        return render_template('recommended.html', games=recommended_games, favorite_games=favorite_games)

    except requests.exceptions.RequestException as e:
        print(f"Error fetching recommended games: {e}")
        return render_template('recommended.html', games=[], favorite_games={})


if __name__ == '__main__':
    app.run(debug=True)
