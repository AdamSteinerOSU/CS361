from flask import Flask, request, jsonify, session
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Adamrocks123!@localhost/cs361'
app.secret_key = 'secretKey'
db = SQLAlchemy(app)


class users(db.Model):
    userID = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(200), unique=True, nullable=False)


@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')

    if not username:
        return jsonify({'error': 'Username is required'}), 400

    user = users.query.filter_by(username=username).first()
    if user:
        session['user_id'] = user.userID
        return jsonify({'message': 'Login successful', 'user_id': user.userID}), 200
    else:
        return jsonify({'error': 'Invalid username'}), 401


if __name__ == '__main__':
    app.run(port=5002)
