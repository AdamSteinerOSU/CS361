from flask import Flask, jsonify, request
from googleapiclient.discovery import build


app = Flask(__name__)

# Set up YouTube Data API client
YOUTUBE_API_KEY = 'AIzaSyCKy2WyrXc1PBUpyraYOjTlZEKaTROhn2g'
youtube = build('youtube', 'v3', developerKey=YOUTUBE_API_KEY)


@app.route('/api/get_trailer', methods=['GET'])
def get_trailer():
    game_name = request.args.get('game_name')

    if not game_name:
        return jsonify({'error': 'Game name is required'}), 400

    try:
        # Search for videos on YouTube
        search_response = youtube.search().list(
            q=game_name + ' trailer',
            part='snippet',
            type='video',
            order='relevance',
            maxResults=1
        ).execute()

        # Get the first video result
        if search_response['items']:
            video = search_response['items'][0]
            video_id = video['id']['videoId']
            video_title = video['snippet']['title']
            video_url = f'https://www.youtube.com/watch?v={video_id}'
            return jsonify({'title': video_title, 'url': video_url})
        else:
            return jsonify({'error': 'No trailers found'}), 404

    except Exception as e:
        return jsonify({'error': str(e)}), 500


if __name__ == '__main__':
    app.run(port=5004, debug=True)
