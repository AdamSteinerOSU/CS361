from flask import Flask, jsonify
import random
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:Adamrocks123!@localhost/cs361'
app.secret_key = 'secretKey'
db = SQLAlchemy(app)

class games(db.Model):
    gameID = db.Column(db.Integer, primary_key=True)
    game_name = db.Column(db.String(200), nullable=False)
    publisher = db.Column(db.String(200))
    date_published = db.Column(db.String(200), default=0)
    rating = db.Column(db.Integer, default=0)
    genres = db.relationship('genres', secondary='game_genres', backref=db.backref('games', lazy='dynamic'))
    platforms = db.relationship('platforms', secondary='game_platforms', backref=db.backref('games', lazy='dynamic'))
    game_description  = db.Column(db.String(500), nullable=False)
    images = db.Column(db.String(245), nullable=False)

    def __repr__(self):
        return '<Game %r>' % self.gameID


class genres(db.Model):
    genreID = db.Column(db.Integer, primary_key=True)
    genre_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<genre %r>' % self.genreID


class game_genres(db.Model):
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)
    genreID = db.Column(db.Integer, db.ForeignKey('genres.genreID'), primary_key=True)

    def __repr__(self):
        return '<genres %r>' %self.gameID


class platforms(db.Model):
    platformID = db.Column(db.Integer, primary_key=True)
    platform_name = db.Column(db.String(200), nullable=False)

    def __repr__(self):
        return '<platform %r>' % self.platformID


class game_platforms(db.Model):
    platformID = db.Column(db.Integer, db.ForeignKey('platforms.platformID'), primary_key=True)
    gameID = db.Column(db.Integer, db.ForeignKey('games.gameID'), primary_key=True)

    def __repr__(self):
        return '<game_platforms %r>' %self.gameID

@app.route('/api/recommended', methods=['GET'])
def get_recommended():
    try:
        all_game_ids = [games.gameID for games in games.query.all()]
        recommended_ids = random.sample(all_game_ids, min(3, len(all_game_ids)))
        return jsonify({'game_ids': recommended_ids})
    except Exception as e:
        print(f"Error generating recommendations: {e}")
        return jsonify({'game_ids': []}), 500

if __name__ == '__main__':
    app.run(port=5003, debug=True)